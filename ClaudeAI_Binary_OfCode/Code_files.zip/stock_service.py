"""
Stock Service
Fetches stock data from Yahoo Finance and manages price updates
"""

import yfinance as yf
from typing import Optional, Dict
from datetime import datetime

class StockService:
    """Handles stock data fetching and price updates"""
    
    def __init__(self):
        pass
    
    def get_stock_info(self, symbol: str) -> Optional[Dict]:
        """
        Get stock information
        Returns: Dict with stock data or None if not found
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            
            if not info or 'symbol' not in info:
                return None
            
            return {
                'symbol': symbol,
                'company_name': info.get('longName', info.get('shortName', symbol)),
                'current_price': info.get('currentPrice', info.get('regularMarketPrice', 0)),
                'previous_close': info.get('previousClose', 0),
                'market_cap': info.get('marketCap', 0),
                'currency': info.get('currency', 'INR'),
                'exchange': info.get('exchange', 'NSE')
            }
        
        except Exception as e:
            print(f"Error fetching stock {symbol}: {e}")
            return None
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current stock price
        Returns: Current price or None if not found
        """
        try:
            ticker = yf.Ticker(symbol)
            
            # Try to get from fast_info first (faster)
            try:
                return ticker.fast_info.last_price
            except:
                pass
            
            # Fallback to regular info
            info = ticker.info
            price = info.get('currentPrice') or info.get('regularMarketPrice')
            
            return float(price) if price else None
        
        except Exception as e:
            print(f"Error fetching price for {symbol}: {e}")
            return None
    
    def get_historical_prices(self, symbol: str, period: str = '1mo') -> Optional[Dict]:
        """
        Get historical prices
        period: 1d, 5d, 1mo, 3mo, 6mo, 1y, 2y, 5y, 10y, ytd, max
        """
        try:
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period=period)
            
            if hist.empty:
                return None
            
            return {
                'dates': hist.index.tolist(),
                'prices': hist['Close'].tolist(),
                'volumes': hist['Volume'].tolist()
            }
        
        except Exception as e:
            print(f"Error fetching historical data for {symbol}: {e}")
            return None
    
    def calculate_pnl(self, avg_price: float, current_price: float, quantity: int) -> Dict:
        """
        Calculate P&L for a position
        Returns: Dict with P&L details
        """
        total_invested = avg_price * quantity
        current_value = current_price * quantity
        
        pnl = current_value - total_invested
        pnl_percentage = (pnl / total_invested * 100) if total_invested > 0 else 0
        
        return {
            'total_invested': total_invested,
            'current_value': current_value,
            'pnl': pnl,
            'pnl_percentage': pnl_percentage
        }
    
    def validate_symbol(self, symbol: str) -> bool:
        """Check if a stock symbol is valid"""
        stock_info = self.get_stock_info(symbol)
        return stock_info is not None
    
    def search_stocks(self, query: str) -> list:
        """
        Search for stocks by name or symbol
        Note: This is a basic implementation. For production, use a dedicated search API
        """
        # Common Indian stocks for demo
        common_stocks = {
            'RELIANCE': 'RELIANCE.NS',
            'TCS': 'TCS.NS',
            'INFY': 'INFY.NS',
            'HDFC': 'HDFCBANK.NS',
            'ICICI': 'ICICIBANK.NS',
            'WIPRO': 'WIPRO.NS',
            'ITC': 'ITC.NS',
            'BHARTI': 'BHARTIARTL.NS',
            'AAPL': 'AAPL',
            'MSFT': 'MSFT',
            'GOOGL': 'GOOGL',
            'AMZN': 'AMZN',
            'TSLA': 'TSLA'
        }
        
        query_upper = query.upper()
        matches = []
        
        for name, symbol in common_stocks.items():
            if query_upper in name or query_upper in symbol:
                matches.append({'name': name, 'symbol': symbol})
        
        return matches
