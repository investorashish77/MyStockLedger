"""
Summary Dialog
Displays AI-generated summaries of corporate announcements
"""

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton,
                             QTextBrowser, QHBoxLayout)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class SummaryDialog(QDialog):
    """Dialog for displaying AI summary"""
    
    def __init__(self, stock_symbol: str, summary_text: str, 
                 sentiment: str, parent=None):
        super().__init__(parent)
        self.stock_symbol = stock_symbol
        self.summary_text = summary_text
        self.sentiment = sentiment
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup UI"""
        self.setWindowTitle(f"AI Summary - {self.stock_symbol}")
        self.setMinimumWidth(600)
        self.setMinimumHeight(500)
        
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Header
        header = QLabel(f"🤖 AI-Generated Summary: {self.stock_symbol}")
        header_font = QFont()
        header_font.setPointSize(14)
        header_font.setBold(True)
        header.setFont(header_font)
        header.setStyleSheet("padding: 10px; background-color: #f5f5f5; border-radius: 4px;")
        layout.addWidget(header)
        
        # Sentiment indicator
        sentiment_color = {
            'POSITIVE': '#4CAF50',
            'NEGATIVE': '#F44336',
            'NEUTRAL': '#FF9800'
        }.get(self.sentiment, '#666')
        
        sentiment_label = QLabel(f"Overall Sentiment: {self.sentiment}")
        sentiment_label.setStyleSheet(f"""
            padding: 8px;
            background-color: {sentiment_color};
            color: white;
            border-radius: 4px;
            font-weight: bold;
        """)
        layout.addWidget(sentiment_label)
        
        # Summary text browser
        browser = QTextBrowser()
        browser.setOpenExternalLinks(True)
        browser.setStyleSheet("""
            QTextBrowser {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 15px;
                background-color: white;
                font-size: 13px;
                line-height: 1.6;
            }
        """)
        
        # Format the summary text
        formatted_summary = self.format_summary(self.summary_text)
        browser.setHtml(formatted_summary)
        
        layout.addWidget(browser)
        
        # Disclaimer
        disclaimer = QLabel(
            "⚠️ Disclaimer: This is an AI-generated summary. "
            "Always verify information and do your own research before making investment decisions."
        )
        disclaimer.setStyleSheet("color: #666; font-size: 11px; padding: 10px;")
        disclaimer.setWordWrap(True)
        layout.addWidget(disclaimer)
        
        # Close button
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 20px;
                background-color: #f0f0f0;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
            }
        """)
        button_layout.addWidget(close_btn)
        
        layout.addLayout(button_layout)
    
    def format_summary(self, text: str) -> str:
        """Format summary text with HTML"""
        # Convert markdown-style formatting to HTML
        html = "<div style='font-family: Arial, sans-serif;'>"
        
        lines = text.split('\n')
        in_list = False
        
        for line in lines:
            line = line.strip()
            
            if not line:
                if in_list:
                    html += "</ul>"
                    in_list = False
                html += "<br>"
                continue
            
            # Headers (lines starting with **)
            if line.startswith('**') and line.endswith('**'):
                if in_list:
                    html += "</ul>"
                    in_list = False
                header_text = line.strip('*').strip()
                html += f"<h3 style='color: #333; margin-top: 15px; margin-bottom: 5px;'>{header_text}</h3>"
            
            # Bullet points
            elif line.startswith('- ') or line.startswith('• '):
                if not in_list:
                    html += "<ul style='margin-left: 20px;'>"
                    in_list = True
                list_text = line[2:].strip()
                html += f"<li style='margin-bottom: 5px;'>{list_text}</li>"
            
            # Regular text
            else:
                if in_list:
                    html += "</ul>"
                    in_list = False
                
                # Bold text
                line = line.replace('**', '<b>').replace('**', '</b>')
                
                html += f"<p style='margin-bottom: 10px;'>{line}</p>"
        
        if in_list:
            html += "</ul>"
        
        html += "</div>"
        
        return html
