"""
Alert Service
Manages price alerts and corporate announcements
"""

from typing import List, Dict
from database.db_manager import DatabaseManager
from services.stock_service import StockService

class AlertService:
    """Handles stock alerts and notifications"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
        self.stock_service = StockService()
    
    def check_price_targets(self, user_id: int) -> List[Dict]:
        """
        Check if any stocks have reached their target prices
        Returns list of triggered alerts
        """
        triggered_alerts = []
        
        # Get user's portfolio
        portfolio = self.db.get_portfolio_summary(user_id)
        
        for stock in portfolio:
            stock_id = stock['stock_id']
            symbol = stock['symbol']
            
            # Get transactions for this stock to check target prices
            transactions = self.db.get_stock_transactions(stock_id)
            
            # Get current price
            current_price = self.stock_service.get_current_price(symbol)
            
            if not current_price:
                continue
            
            # Check each transaction's target price
            for trans in transactions:
                if trans['target_price'] and current_price >= trans['target_price']:
                    alert_message = f"{symbol} has reached target price ₹{trans['target_price']:.2f} (Current: ₹{current_price:.2f})"
                    
                    # Add alert to database
                    alert_id = self.db.add_alert(
                        stock_id=stock_id,
                        alert_type='PRICE_TARGET',
                        alert_message=alert_message
                    )
                    
                    triggered_alerts.append({
                        'alert_id': alert_id,
                        'stock_id': stock_id,
                        'symbol': symbol,
                        'message': alert_message
                    })
        
        return triggered_alerts
    
    def create_manual_alert(self, stock_id: int, alert_type: str, 
                           message: str, details: str = None, url: str = None) -> int:
        """Create a manual alert (for announcements, news, etc.)"""
        return self.db.add_alert(
            stock_id=stock_id,
            alert_type=alert_type,
            alert_message=message,
            announcement_details=details,
            announcement_url=url
        )
    
    def get_user_alerts(self, user_id: int, unread_only: bool = False) -> List[Dict]:
        """Get all alerts for a user"""
        return self.db.get_user_alerts(user_id, unread_only)
    
    def mark_as_read(self, alert_id: int):
        """Mark an alert as read"""
        self.db.mark_alert_as_read(alert_id)
    
    # Placeholder for future implementation
    def fetch_corporate_announcements(self, symbol: str) -> List[Dict]:
        """
        Fetch corporate announcements from NSE/BSE
        This is a placeholder - actual implementation would scrape NSE/BSE websites
        """
        # TODO: Implement web scraping for NSE/BSE announcements
        # For now, return empty list
        return []
    
    def create_sample_alert(self, user_id: int, stock_symbol: str) -> int:
        """Create a sample announcement alert for testing"""
        # Get stock_id
        stocks = self.db.get_user_stocks(user_id)
        stock = next((s for s in stocks if s['symbol'] == stock_symbol), None)
        
        if not stock:
            return None
        
        sample_announcement = """
Company announces Q3 FY25 results:
- Revenue: ₹25,000 Cr (↑12% YoY)
- Net Profit: ₹3,500 Cr (↑18% YoY)
- EBITDA Margin: 22.5% (↑150 bps)
- EPS: ₹45.2 (↑17% YoY)

Management Commentary:
- Strong performance across all business segments
- Digital transformation initiatives showing results
- Raised FY25 guidance by 5%

Board approved interim dividend of ₹10 per share.
        """
        
        return self.create_manual_alert(
            stock_id=stock['stock_id'],
            alert_type='ANNOUNCEMENT',
            message=f"{stock_symbol} Q3 Results Announced - Revenue up 12% YoY",
            details=sample_announcement,
            url="https://www.nseindia.com"
        )
