"""
Alerts View
Displays alerts and notifications for stocks
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QTableWidget, QTableWidgetItem, QLabel, QHeaderView,
                             QMessageBox, QCheckBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor
from database.db_manager import DatabaseManager
from services.alert_service import AlertService
from services.ai_summary_service import AISummaryService
from ui.summary_dialog import SummaryDialog

class AlertsView(QWidget):
    """Alerts view widget"""
    
    def __init__(self, db: DatabaseManager, alert_service: AlertService, 
                 ai_service: AISummaryService):
        super().__init__()
        self.db = db
        self.alert_service = alert_service
        self.ai_service = ai_service
        self.current_user_id = None
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup UI"""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Header
        header = QHBoxLayout()
        
        title = QLabel("Alerts & Notifications")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        header.addWidget(title)
        
        header.addStretch()
        
        # Show unread only checkbox
        self.unread_only_checkbox = QCheckBox("Show unread only")
        self.unread_only_checkbox.stateChanged.connect(self.filter_changed)
        header.addWidget(self.unread_only_checkbox)
        
        # Create sample alert button (for demo)
        sample_btn = QPushButton("+ Create Sample Alert")
        sample_btn.clicked.connect(self.create_sample_alert)
        sample_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                padding: 8px 16px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #0b7dda;
            }
        """)
        header.addWidget(sample_btn)
        
        layout.addLayout(header)
        
        # Alerts table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels([
            'Symbol', 'Type', 'Message', 'Date/Time', 'Status', 'Actions'
        ])
        
        # Set column widths
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        
        self.table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            QHeaderView::section {
                background-color: #f0f0f0;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
            QTableWidget::item {
                padding: 8px;
            }
        """)
        
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        
        layout.addWidget(self.table)
        
        # Info label
        self.info_label = QLabel()
        self.info_label.setStyleSheet("color: #666; padding: 10px;")
        layout.addWidget(self.info_label)
    
    def load_alerts(self, user_id: int):
        """Load alerts for user"""
        self.current_user_id = user_id
        
        unread_only = self.unread_only_checkbox.isChecked()
        alerts = self.alert_service.get_user_alerts(user_id, unread_only)
        
        self.table.setRowCount(0)
        
        if not alerts:
            self.info_label.setText(
                "No alerts yet. Alerts will appear here when:\n"
                "• Stocks reach target prices\n"
                "• Corporate announcements are published\n"
                "• Price changes exceed thresholds"
            )
            return
        
        self.info_label.setText(f"Showing {len(alerts)} alert(s)")
        
        # Populate table
        for i, alert in enumerate(alerts):
            self.table.insertRow(i)
            
            # Symbol
            self.table.setItem(i, 0, QTableWidgetItem(alert['symbol']))
            
            # Type
            type_item = QTableWidgetItem(alert['alert_type'])
            if alert['alert_type'] == 'PRICE_TARGET':
                type_item.setForeground(QColor('#4CAF50'))
            elif alert['alert_type'] == 'ANNOUNCEMENT':
                type_item.setForeground(QColor('#2196F3'))
            self.table.setItem(i, 1, type_item)
            
            # Message
            self.table.setItem(i, 2, QTableWidgetItem(alert['alert_message']))
            
            # Date/Time
            self.table.setItem(i, 3, QTableWidgetItem(alert['triggered_at']))
            
            # Status
            status_item = QTableWidgetItem('Read' if alert['is_read'] else 'Unread')
            if not alert['is_read']:
                status_item.setForeground(QColor('#FF9800'))
                status_item.setFont(QFont('Arial', 10, QFont.Bold))
            self.table.setItem(i, 4, status_item)
            
            # Actions
            actions_widget = QWidget()
            actions_layout = QHBoxLayout()
            actions_layout.setContentsMargins(5, 2, 5, 2)
            actions_widget.setLayout(actions_layout)
            
            # View details button
            view_btn = QPushButton("View")
            view_btn.setStyleSheet("""
                QPushButton {
                    padding: 4px 12px;
                    background-color: #f0f0f0;
                    border: 1px solid #ccc;
                    border-radius: 3px;
                }
                QPushButton:hover {
                    background-color: #e0e0e0;
                }
            """)
            view_btn.clicked.connect(lambda checked, a=alert: self.view_alert_details(a))
            actions_layout.addWidget(view_btn)
            
            # AI Summary button (if announcement has details)
            if alert['announcement_details'] and self.ai_service.is_available():
                ai_btn = QPushButton("🤖 Summary")
                ai_btn.setStyleSheet("""
                    QPushButton {
                        padding: 4px 12px;
                        background-color: #4CAF50;
                        color: white;
                        border: none;
                        border-radius: 3px;
                    }
                    QPushButton:hover {
                        background-color: #45a049;
                    }
                """)
                ai_btn.clicked.connect(lambda checked, a=alert: self.generate_summary(a))
                actions_layout.addWidget(ai_btn)
            
            self.table.setCellWidget(i, 5, actions_widget)
            
            # Store alert data
            self.table.item(i, 0).setData(Qt.UserRole, alert)
    
    def filter_changed(self):
        """Handle filter checkbox change"""
        if self.current_user_id:
            self.load_alerts(self.current_user_id)
    
    def view_alert_details(self, alert):
        """View full alert details"""
        # Mark as read
        if not alert['is_read']:
            self.alert_service.mark_as_read(alert['alert_id'])
            self.load_alerts(self.current_user_id)
        
        # Show details
        details = f"<h3>{alert['symbol']} - {alert['alert_type']}</h3>"
        details += f"<p><b>Date:</b> {alert['triggered_at']}</p>"
        details += f"<p><b>Message:</b> {alert['alert_message']}</p>"
        
        if alert['announcement_details']:
            details += f"<hr><pre>{alert['announcement_details']}</pre>"
        
        if alert['announcement_url']:
            details += f"<p><a href='{alert['announcement_url']}'>View Source</a></p>"
        
        QMessageBox.information(self, f"{alert['symbol']} Alert", details)
    
    def generate_summary(self, alert):
        """Generate AI summary for announcement"""
        # Check if summary already exists
        existing_summary = self.db.get_alert_summary(alert['alert_id'])
        
        if existing_summary:
            # Show existing summary
            dialog = SummaryDialog(
                alert['symbol'],
                existing_summary['summary_text'],
                existing_summary['sentiment'],
                parent=self
            )
            dialog.exec_()
            return
        
        # Generate new summary
        QMessageBox.information(
            self, 
            "Generating Summary", 
            "Generating AI summary... This may take a few seconds."
        )
        
        try:
            result = self.ai_service.generate_summary(
                stock_symbol=alert['symbol'],
                announcement_text=alert['announcement_details'],
                announcement_type=alert['alert_type']
            )
            
            if result:
                # Save summary
                self.db.save_ai_summary(
                    alert_id=alert['alert_id'],
                    summary_text=result['summary_text'],
                    sentiment=result['sentiment']
                )
                
                # Show summary
                dialog = SummaryDialog(
                    alert['symbol'],
                    result['summary_text'],
                    result['sentiment'],
                    parent=self
                )
                dialog.exec_()
            else:
                QMessageBox.warning(
                    self,
                    "Error",
                    "Failed to generate summary. Please check your AI API configuration."
                )
        
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate summary: {str(e)}")
    
    def create_sample_alert(self):
        """Create a sample alert for demonstration"""
        if not self.current_user_id:
            return
        
        # Get user's stocks
        stocks = self.db.get_user_stocks(self.current_user_id)
        
        if not stocks:
            QMessageBox.information(
                self,
                "No Stocks",
                "Please add stocks to your portfolio first."
            )
            return
        
        # Create sample alert for first stock
        stock = stocks[0]
        self.alert_service.create_sample_alert(self.current_user_id, stock['symbol'])
        
        QMessageBox.information(
            self,
            "Sample Alert Created",
            f"Sample announcement created for {stock['symbol']}.\n\n"
            f"Click '🤖 Summary' to generate an AI-powered summary!"
        )
        
        # Reload alerts
        self.load_alerts(self.current_user_id)
