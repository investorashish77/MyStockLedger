"""
Add Stock Dialog
Dialog for adding stocks and transactions to portfolio
"""

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                             QLineEdit, QPushButton, QComboBox, QTextEdit,
                             QDateEdit, QSpinBox, QDoubleSpinBox, QMessageBox,
                             QFormLayout, QGroupBox)
from PyQt5.QtCore import Qt, QDate
from datetime import datetime
from database.db_manager import DatabaseManager
from services.stock_service import StockService

class AddStockDialog(QDialog):
    """Dialog for adding a stock and its first transaction"""
    
    def __init__(self, db: DatabaseManager, stock_service: StockService, 
                 user_id: int, parent=None):
        super().__init__(parent)
        self.db = db
        self.stock_service = stock_service
        self.user_id = user_id
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup UI"""
        self.setWindowTitle("Add Stock to Portfolio")
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Stock details group
        stock_group = QGroupBox("Stock Details")
        stock_layout = QFormLayout()
        stock_group.setLayout(stock_layout)
        
        # Symbol
        self.symbol_input = QLineEdit()
        self.symbol_input.setPlaceholderText("e.g., RELIANCE.NS, AAPL, TCS.NS")
        self.symbol_input.textChanged.connect(self.on_symbol_changed)
        stock_layout.addRow("Symbol:", self.symbol_input)
        
        # Company name (auto-filled)
        self.company_name_label = QLabel("Enter symbol to fetch company name")
        self.company_name_label.setStyleSheet("color: #666;")
        stock_layout.addRow("Company:", self.company_name_label)
        
        layout.addWidget(stock_group)
        
        # Transaction details group
        trans_group = QGroupBox("Transaction Details")
        trans_layout = QFormLayout()
        trans_group.setLayout(trans_layout)
        
        # Transaction type
        self.transaction_type = QComboBox()
        self.transaction_type.addItems(['BUY', 'SELL'])
        trans_layout.addRow("Type:", self.transaction_type)
        
        # Quantity
        self.quantity_input = QSpinBox()
        self.quantity_input.setMinimum(1)
        self.quantity_input.setMaximum(1000000)
        self.quantity_input.setValue(10)
        trans_layout.addRow("Quantity:", self.quantity_input)
        
        # Price per share
        self.price_input = QDoubleSpinBox()
        self.price_input.setMinimum(0.01)
        self.price_input.setMaximum(1000000.0)
        self.price_input.setDecimals(2)
        self.price_input.setValue(100.0)
        self.price_input.setPrefix("₹ ")
        trans_layout.addRow("Price per Share:", self.price_input)
        
        # Date
        self.date_input = QDateEdit()
        self.date_input.setDate(QDate.currentDate())
        self.date_input.setCalendarPopup(True)
        trans_layout.addRow("Date:", self.date_input)
        
        layout.addWidget(trans_group)
        
        # Investment strategy group
        strategy_group = QGroupBox("Investment Strategy")
        strategy_layout = QFormLayout()
        strategy_group.setLayout(strategy_layout)
        
        # Investment horizon
        self.horizon_input = QComboBox()
        self.horizon_input.addItems(['SHORT', 'MEDIUM', 'LONG'])
        self.horizon_input.setCurrentText('LONG')
        strategy_layout.addRow("Investment Horizon:", self.horizon_input)
        
        # Target price
        self.target_price_input = QDoubleSpinBox()
        self.target_price_input.setMinimum(0.0)
        self.target_price_input.setMaximum(1000000.0)
        self.target_price_input.setDecimals(2)
        self.target_price_input.setValue(150.0)
        self.target_price_input.setPrefix("₹ ")
        strategy_layout.addRow("Target Price:", self.target_price_input)
        
        # Investment thesis
        self.thesis_input = QTextEdit()
        self.thesis_input.setPlaceholderText(
            "Why are you buying this stock?\n\n"
            "Example:\n"
            "- Strong fundamentals with 20% YoY revenue growth\n"
            "- Expanding into new markets\n"
            "- Undervalued compared to peers (P/E: 15 vs industry avg 25)"
        )
        self.thesis_input.setMaximumHeight(120)
        strategy_layout.addRow("Investment Thesis:", self.thesis_input)
        
        layout.addWidget(strategy_group)
        
        # Buttons
        buttons = QHBoxLayout()
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        buttons.addWidget(cancel_btn)
        
        add_btn = QPushButton("Add to Portfolio")
        add_btn.clicked.connect(self.add_stock)
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        buttons.addWidget(add_btn)
        
        layout.addLayout(buttons)
    
    def on_symbol_changed(self, text):
        """Fetch company name when symbol changes"""
        symbol = text.strip().upper()
        
        if len(symbol) < 2:
            self.company_name_label.setText("Enter symbol to fetch company name")
            self.company_name_label.setStyleSheet("color: #666;")
            return
        
        # Fetch stock info
        stock_info = self.stock_service.get_stock_info(symbol)
        
        if stock_info:
            self.company_name_label.setText(stock_info['company_name'])
            self.company_name_label.setStyleSheet("color: #4CAF50;")
            
            # Auto-fill current price as purchase price
            if stock_info['current_price'] > 0:
                self.price_input.setValue(stock_info['current_price'])
                self.target_price_input.setValue(stock_info['current_price'] * 1.2)  # 20% target
        else:
            self.company_name_label.setText("❌ Stock not found. Check symbol.")
            self.company_name_label.setStyleSheet("color: #F44336;")
    
    def add_stock(self):
        """Add stock and transaction to database"""
        symbol = self.symbol_input.text().strip().upper()
        
        if not symbol:
            QMessageBox.warning(self, "Error", "Please enter a stock symbol")
            return
        
        # Validate stock
        stock_info = self.stock_service.get_stock_info(symbol)
        if not stock_info:
            QMessageBox.warning(self, "Error", "Invalid stock symbol. Please check and try again.")
            return
        
        # Get form data
        company_name = stock_info['company_name']
        exchange = stock_info['exchange']
        transaction_type = self.transaction_type.currentText()
        quantity = self.quantity_input.value()
        price = self.price_input.value()
        date = self.date_input.date().toString('yyyy-MM-dd')
        horizon = self.horizon_input.currentText()
        target_price = self.target_price_input.value()
        thesis = self.thesis_input.toPlainText().strip()
        
        try:
            # Add stock (or get existing)
            stock_id = self.db.add_stock(self.user_id, symbol, company_name, exchange)
            
            # Add transaction
            self.db.add_transaction(
                stock_id=stock_id,
                transaction_type=transaction_type,
                quantity=quantity,
                price_per_share=price,
                transaction_date=date,
                investment_horizon=horizon,
                target_price=target_price if target_price > 0 else None,
                thesis=thesis if thesis else None
            )
            
            # Save current price
            if stock_info['current_price'] > 0:
                self.db.save_price(stock_id, stock_info['current_price'])
            
            QMessageBox.information(
                self, 
                "Success", 
                f"{symbol} added to your portfolio successfully!"
            )
            
            self.accept()
        
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to add stock: {str(e)}")
