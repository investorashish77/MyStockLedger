"""
Database Manager
Handles all database operations for the Equity Tracker app
"""

import sqlite3
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple

class DatabaseManager:
    """Manages database operations"""
    
    def __init__(self, db_path: str = 'data/equity_tracker.db'):
        self.db_path = db_path
        self._ensure_database_exists()
    
    def _ensure_database_exists(self):
        """Ensure database file and tables exist"""
        db_file = Path(self.db_path)
        if not db_file.parent.exists():
            db_file.parent.mkdir(parents=True, exist_ok=True)
        
        # If database doesn't exist, create it with schema
        if not db_file.exists():
            self._create_schema()
    
    def _create_schema(self):
        """Create database schema"""
        schema_path = Path(__file__).parent / 'schema.sql'
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                schema = f.read()
            
            conn = self.get_connection()
            conn.executescript(schema)
            conn.commit()
            conn.close()
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    # User operations
    def create_user(self, mobile_number: str, name: str, password_hash: str, email: str = None) -> int:
        """Create a new user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO users (mobile_number, name, email, password_hash)
            VALUES (?, ?, ?, ?)
        """, (mobile_number, name, email, password_hash))
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return user_id
    
    def get_user_by_mobile(self, mobile_number: str) -> Optional[Dict]:
        """Get user by mobile number"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT user_id, mobile_number, name, email, password_hash, created_at
            FROM users WHERE mobile_number = ?
        """, (mobile_number,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'user_id': row[0],
                'mobile_number': row[1],
                'name': row[2],
                'email': row[3],
                'password_hash': row[4],
                'created_at': row[5]
            }
        return None
    
    # Stock operations
    def add_stock(self, user_id: int, symbol: str, company_name: str, exchange: str = 'NSE') -> int:
        """Add a stock to user's portfolio"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Check if stock already exists for user
        cursor.execute("""
            SELECT stock_id FROM stocks 
            WHERE user_id = ? AND symbol = ?
        """, (user_id, symbol))
        
        existing = cursor.fetchone()
        if existing:
            conn.close()
            return existing[0]
        
        cursor.execute("""
            INSERT INTO stocks (user_id, symbol, company_name, exchange)
            VALUES (?, ?, ?, ?)
        """, (user_id, symbol, company_name, exchange))
        
        stock_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return stock_id
    
    def get_user_stocks(self, user_id: int) -> List[Dict]:
        """Get all stocks for a user"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT stock_id, symbol, company_name, exchange
            FROM stocks WHERE user_id = ?
            ORDER BY symbol
        """, (user_id,))
        
        stocks = []
        for row in cursor.fetchall():
            stocks.append({
                'stock_id': row[0],
                'symbol': row[1],
                'company_name': row[2],
                'exchange': row[3]
            })
        
        conn.close()
        return stocks
    
    # Transaction operations
    def add_transaction(self, stock_id: int, transaction_type: str, quantity: int, 
                       price_per_share: float, transaction_date: str, 
                       investment_horizon: str, target_price: float = None, 
                       thesis: str = None) -> int:
        """Add a buy/sell transaction"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO transactions 
            (stock_id, transaction_type, quantity, price_per_share, transaction_date,
             investment_horizon, target_price, thesis)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (stock_id, transaction_type, quantity, price_per_share, transaction_date,
              investment_horizon, target_price, thesis))
        
        transaction_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return transaction_id
    
    def get_stock_transactions(self, stock_id: int) -> List[Dict]:
        """Get all transactions for a stock"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT transaction_id, transaction_type, quantity, price_per_share,
                   transaction_date, investment_horizon, target_price, thesis
            FROM transactions WHERE stock_id = ?
            ORDER BY transaction_date DESC
        """, (stock_id,))
        
        transactions = []
        for row in cursor.fetchall():
            transactions.append({
                'transaction_id': row[0],
                'transaction_type': row[1],
                'quantity': row[2],
                'price_per_share': row[3],
                'transaction_date': row[4],
                'investment_horizon': row[5],
                'target_price': row[6],
                'thesis': row[7]
            })
        
        conn.close()
        return transactions
    
    def get_portfolio_summary(self, user_id: int) -> List[Dict]:
        """Get portfolio summary with holdings"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT 
                s.stock_id, s.symbol, s.company_name,
                SUM(CASE WHEN t.transaction_type = 'BUY' THEN t.quantity ELSE -t.quantity END) as total_quantity,
                SUM(CASE WHEN t.transaction_type = 'BUY' THEN t.quantity * t.price_per_share ELSE 0 END) /
                    NULLIF(SUM(CASE WHEN t.transaction_type = 'BUY' THEN t.quantity ELSE 0 END), 0) as avg_price
            FROM stocks s
            LEFT JOIN transactions t ON s.stock_id = t.stock_id
            WHERE s.user_id = ?
            GROUP BY s.stock_id, s.symbol, s.company_name
            HAVING total_quantity > 0
        """, (user_id,))
        
        portfolio = []
        for row in cursor.fetchall():
            portfolio.append({
                'stock_id': row[0],
                'symbol': row[1],
                'company_name': row[2],
                'quantity': row[3],
                'avg_price': row[4] or 0
            })
        
        conn.close()
        return portfolio
    
    # Alert operations
    def add_alert(self, stock_id: int, alert_type: str, alert_message: str,
                 announcement_details: str = None, announcement_url: str = None) -> int:
        """Add an alert"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO alerts 
            (stock_id, alert_type, alert_message, announcement_details, announcement_url)
            VALUES (?, ?, ?, ?, ?)
        """, (stock_id, alert_type, alert_message, announcement_details, announcement_url))
        
        alert_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return alert_id
    
    def get_user_alerts(self, user_id: int, unread_only: bool = False) -> List[Dict]:
        """Get alerts for user's stocks"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT a.alert_id, a.stock_id, s.symbol, a.alert_type, 
                   a.alert_message, a.announcement_details, a.announcement_url,
                   a.triggered_at, a.is_read
            FROM alerts a
            JOIN stocks s ON a.stock_id = s.stock_id
            WHERE s.user_id = ?
        """
        
        if unread_only:
            query += " AND a.is_read = 0"
        
        query += " ORDER BY a.triggered_at DESC"
        
        cursor.execute(query, (user_id,))
        
        alerts = []
        for row in cursor.fetchall():
            alerts.append({
                'alert_id': row[0],
                'stock_id': row[1],
                'symbol': row[2],
                'alert_type': row[3],
                'alert_message': row[4],
                'announcement_details': row[5],
                'announcement_url': row[6],
                'triggered_at': row[7],
                'is_read': bool(row[8])
            })
        
        conn.close()
        return alerts
    
    def mark_alert_as_read(self, alert_id: int):
        """Mark an alert as read"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE alerts SET is_read = 1 WHERE alert_id = ?", (alert_id,))
        
        conn.commit()
        conn.close()
    
    # AI Summary operations
    def save_ai_summary(self, alert_id: int, summary_text: str, 
                       sentiment: str, impact_analysis: str = None) -> int:
        """Save AI-generated summary"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO ai_summaries (alert_id, summary_text, sentiment, impact_analysis)
            VALUES (?, ?, ?, ?)
        """, (alert_id, summary_text, sentiment, impact_analysis))
        
        summary_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return summary_id
    
    def get_alert_summary(self, alert_id: int) -> Optional[Dict]:
        """Get AI summary for an alert"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT summary_id, summary_text, sentiment, impact_analysis, generated_at
            FROM ai_summaries WHERE alert_id = ?
            ORDER BY generated_at DESC LIMIT 1
        """, (alert_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'summary_id': row[0],
                'summary_text': row[1],
                'sentiment': row[2],
                'impact_analysis': row[3],
                'generated_at': row[4]
            }
        return None
    
    # Price history operations
    def save_price(self, stock_id: int, price: float):
        """Save current stock price"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO price_history (stock_id, price)
            VALUES (?, ?)
        """, (stock_id, price))
        
        conn.commit()
        conn.close()
    
    def get_latest_price(self, stock_id: int) -> Optional[float]:
        """Get latest price for a stock"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT price FROM price_history 
            WHERE stock_id = ?
            ORDER BY recorded_at DESC LIMIT 1
        """, (stock_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        return row[0] if row else None
