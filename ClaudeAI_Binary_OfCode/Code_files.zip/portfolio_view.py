"""
Portfolio View
Displays user's stock portfolio with P&L calculations
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
                             QTableWidget, QTableWidgetItem, QLabel, QHeaderView,
                             QMessageBox)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor
from database.db_manager import DatabaseManager
from services.stock_service import StockService
from ui.add_stock_dialog import AddStockDialog

class PortfolioView(QWidget):
    """Portfolio view widget"""
    
    def __init__(self, db: DatabaseManager, stock_service: StockService):
        super().__init__()
        self.db = db
        self.stock_service = stock_service
        self.current_user_id = None
        
        self.setup_ui()
    
    def setup_ui(self):
        """Setup UI"""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Header with Add Stock button
        header = QHBoxLayout()
        
        title = QLabel("My Portfolio")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title.setFont(title_font)
        header.addWidget(title)
        
        header.addStretch()
        
        add_btn = QPushButton("+ Add Stock")
        add_btn.clicked.connect(self.add_stock)
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        header.addWidget(add_btn)
        
        layout.addLayout(header)
        
        # Portfolio summary
        self.summary_label = QLabel()
        self.summary_label.setStyleSheet("""
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 4px;
            margin: 10px 0px;
        """)
        layout.addWidget(self.summary_label)
        
        # Portfolio table
        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            'Symbol', 'Company', 'Quantity', 'Avg Price', 
            'Current Price', 'Investment', 'Current Value', 'P&L'
        ])
        
        # Set column widths
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        
        self.table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            QHeaderView::section {
                background-color: #f0f0f0;
                padding: 8px;
                border: none;
                font-weight: bold;
            }
            QTableWidget::item {
                padding: 8px;
            }
        """)
        
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.doubleClicked.connect(self.view_stock_details)
        
        layout.addWidget(self.table)
        
        # Instructions
        instructions = QLabel("💡 Tip: Double-click a stock to view details and add transactions")
        instructions.setStyleSheet("color: #666; padding: 10px;")
        layout.addWidget(instructions)
    
    def load_portfolio(self, user_id: int):
        """Load portfolio for user"""
        self.current_user_id = user_id
        self.table.setRowCount(0)
        
        # Get portfolio
        portfolio = self.db.get_portfolio_summary(user_id)
        
        if not portfolio:
            self.summary_label.setText("No stocks in portfolio. Click '+ Add Stock' to get started!")
            return
        
        # Calculate totals
        total_invested = 0
        total_current_value = 0
        
        # Populate table
        for i, stock in enumerate(portfolio):
            self.table.insertRow(i)
            
            symbol = stock['symbol']
            quantity = stock['quantity']
            avg_price = stock['avg_price']
            
            # Get current price
            current_price = self.stock_service.get_current_price(symbol)
            
            if current_price is None:
                current_price = avg_price  # Fallback
            
            # Calculate values
            investment = avg_price * quantity
            current_value = current_price * quantity
            pnl = current_value - investment
            pnl_pct = (pnl / investment * 100) if investment > 0 else 0
            
            total_invested += investment
            total_current_value += current_value
            
            # Add to table
            self.table.setItem(i, 0, QTableWidgetItem(symbol))
            self.table.setItem(i, 1, QTableWidgetItem(stock['company_name']))
            self.table.setItem(i, 2, QTableWidgetItem(str(int(quantity))))
            self.table.setItem(i, 3, QTableWidgetItem(f"₹{avg_price:.2f}"))
            self.table.setItem(i, 4, QTableWidgetItem(f"₹{current_price:.2f}"))
            self.table.setItem(i, 5, QTableWidgetItem(f"₹{investment:,.2f}"))
            self.table.setItem(i, 6, QTableWidgetItem(f"₹{current_value:,.2f}"))
            
            # P&L with color
            pnl_item = QTableWidgetItem(f"₹{pnl:,.2f} ({pnl_pct:+.2f}%)")
            if pnl > 0:
                pnl_item.setForeground(QColor('#4CAF50'))
            elif pnl < 0:
                pnl_item.setForeground(QColor('#F44336'))
            self.table.setItem(i, 7, pnl_item)
            
            # Store stock_id in row
            self.table.item(i, 0).setData(Qt.UserRole, stock['stock_id'])
        
        # Update summary
        total_pnl = total_current_value - total_invested
        total_pnl_pct = (total_pnl / total_invested * 100) if total_invested > 0 else 0
        
        summary_color = '#4CAF50' if total_pnl >= 0 else '#F44336'
        
        self.summary_label.setText(f"""
            <b>Portfolio Summary:</b> &nbsp;&nbsp;
            Total Invested: ₹{total_invested:,.2f} &nbsp;|&nbsp;
            Current Value: ₹{total_current_value:,.2f} &nbsp;|&nbsp;
            <span style='color: {summary_color};'>
            P&L: ₹{total_pnl:,.2f} ({total_pnl_pct:+.2f}%)
            </span>
        """)
    
    def add_stock(self):
        """Open add stock dialog"""
        if not self.current_user_id:
            return
        
        dialog = AddStockDialog(self.db, self.stock_service, self.current_user_id, parent=self)
        if dialog.exec_():
            # Reload portfolio
            self.load_portfolio(self.current_user_id)
    
    def view_stock_details(self, index):
        """View stock details when double-clicked"""
        row = index.row()
        stock_id = self.table.item(row, 0).data(Qt.UserRole)
        symbol = self.table.item(row, 0).text()
        
        # Get transactions for this stock
        transactions = self.db.get_stock_transactions(stock_id)
        
        # Show details dialog (simplified for now)
        details = f"<h3>{symbol} - Transactions</h3><table border='1' cellpadding='5'>"
        details += "<tr><th>Date</th><th>Type</th><th>Qty</th><th>Price</th><th>Horizon</th><th>Target</th></tr>"
        
        for trans in transactions:
            details += f"""
            <tr>
                <td>{trans['transaction_date']}</td>
                <td>{trans['transaction_type']}</td>
                <td>{trans['quantity']}</td>
                <td>₹{trans['price_per_share']:.2f}</td>
                <td>{trans['investment_horizon']}</td>
                <td>₹{trans['target_price']:.2f if trans['target_price'] else 'N/A'}</td>
            </tr>
            """
        
        details += "</table>"
        
        if transactions and transactions[0]['thesis']:
            details += f"<p><b>Investment Thesis:</b><br>{transactions[0]['thesis']}</p>"
        
        QMessageBox.information(self, f"{symbol} Details", details)
