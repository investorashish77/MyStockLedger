"""
AI Summary Service
Generates AI-powered summaries of corporate announcements
Supports multiple AI providers: Groq (free), Claude, OpenAI
"""

from typing import Dict, Optional
from utils.config import config

class AISummaryService:
    """Generates AI summaries using configured provider"""
    
    def __init__(self):
        self.provider = config.AI_PROVIDER
        self.client = None
        
        # Initialize the appropriate AI client
        if self.provider == 'groq' and config.GROQ_API_KEY:
            try:
                from groq import Groq
                self.client = Groq(api_key=config.GROQ_API_KEY)
            except ImportError:
                print("Groq package not installed. Run: pip install groq")
        
        elif self.provider == 'claude' and config.CLAUDE_API_KEY:
            try:
                from anthropic import Anthropic
                self.client = Anthropic(api_key=config.CLAUDE_API_KEY)
            except ImportError:
                print("Anthropic package not installed. Run: pip install anthropic")
        
        elif self.provider == 'openai' and config.OPENAI_API_KEY:
            try:
                from openai import OpenAI
                self.client = OpenAI(api_key=config.OPENAI_API_KEY)
            except ImportError:
                print("OpenAI package not installed. Run: pip install openai")
    
    def is_available(self) -> bool:
        """Check if AI service is available"""
        return self.client is not None
    
    def generate_summary(self, stock_symbol: str, announcement_text: str, 
                        announcement_type: str = "ANNOUNCEMENT") -> Optional[Dict]:
        """
        Generate AI summary of corporate announcement
        
        Args:
            stock_symbol: Stock symbol (e.g., RELIANCE.NS)
            announcement_text: Full announcement text
            announcement_type: Type of announcement
        
        Returns:
            Dict with summary_text and sentiment, or None if failed
        """
        if not self.is_available():
            return None
        
        # Create prompt
        prompt = self._create_prompt(stock_symbol, announcement_text, announcement_type)
        
        try:
            # Generate summary based on provider
            if self.provider == 'groq':
                return self._generate_groq_summary(prompt)
            elif self.provider == 'claude':
                return self._generate_claude_summary(prompt)
            elif self.provider == 'openai':
                return self._generate_openai_summary(prompt)
        
        except Exception as e:
            print(f"Error generating AI summary: {e}")
            return None
    
    def _create_prompt(self, stock_symbol: str, announcement_text: str, 
                      announcement_type: str) -> str:
        """Create the prompt for AI summary"""
        return f"""You are a financial analyst. Analyze this corporate announcement for {stock_symbol}:

Type: {announcement_type}
Announcement: {announcement_text}

Provide a concise summary with the following structure:

**WHAT HAPPENED:**
[2-3 sentences explaining the announcement in simple terms]

**WHY IT MATTERS:**
[2-3 sentences on significance for investors]

**IMPACT ASSESSMENT:**
[Positive/Neutral/Negative and why]

**KEY POINTS:**
- [Bullet point 1]
- [Bullet point 2]
- [Bullet point 3]

**RISKS/OPPORTUNITIES:**
[1-2 sentences on potential risks or opportunities]

**SENTIMENT:** [Positive/Neutral/Negative]

Keep the entire summary under 250 words. Be objective and factual."""
    
    def _generate_groq_summary(self, prompt: str) -> Dict:
        """Generate summary using Groq"""
        response = self.client.chat.completions.create(
            model="llama-3.3-70b-versatile",  # Free tier model
            messages=[
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.3
        )
        
        summary_text = response.choices[0].message.content
        sentiment = self._extract_sentiment(summary_text)
        
        return {
            'summary_text': summary_text,
            'sentiment': sentiment,
            'provider': 'groq'
        }
    
    def _generate_claude_summary(self, prompt: str) -> Dict:
        """Generate summary using Claude"""
        response = self.client.messages.create(
            model="claude-haiku-4-5-20251001",  # Most economical
            max_tokens=500,
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        summary_text = response.content[0].text
        sentiment = self._extract_sentiment(summary_text)
        
        return {
            'summary_text': summary_text,
            'sentiment': sentiment,
            'provider': 'claude'
        }
    
    def _generate_openai_summary(self, prompt: str) -> Dict:
        """Generate summary using OpenAI"""
        response = self.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "user", "content": prompt}
            ],
            max_tokens=500,
            temperature=0.3
        )
        
        summary_text = response.choices[0].message.content
        sentiment = self._extract_sentiment(summary_text)
        
        return {
            'summary_text': summary_text,
            'sentiment': sentiment,
            'provider': 'openai'
        }
    
    def _extract_sentiment(self, summary_text: str) -> str:
        """Extract sentiment from summary"""
        summary_lower = summary_text.lower()
        
        # Look for explicit sentiment marker
        if 'sentiment: positive' in summary_lower or 'sentiment:** positive' in summary_lower:
            return 'POSITIVE'
        elif 'sentiment: negative' in summary_lower or 'sentiment:** negative' in summary_lower:
            return 'NEGATIVE'
        elif 'sentiment: neutral' in summary_lower or 'sentiment:** neutral' in summary_lower:
            return 'NEUTRAL'
        
        # Fallback: analyze content
        positive_words = ['positive', 'growth', 'increase', 'profit', 'success', 'strong', 'up']
        negative_words = ['negative', 'decline', 'loss', 'weak', 'down', 'concern', 'risk']
        
        positive_count = sum(1 for word in positive_words if word in summary_lower)
        negative_count = sum(1 for word in negative_words if word in summary_lower)
        
        if positive_count > negative_count:
            return 'POSITIVE'
        elif negative_count > positive_count:
            return 'NEGATIVE'
        
        return 'NEUTRAL'
