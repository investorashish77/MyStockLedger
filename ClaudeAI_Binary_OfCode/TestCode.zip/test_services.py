"""
Unit Tests for Equity Tracker Services
Tests all service layer functionality
"""

import unittest
import sys
import os
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from database.db_manager import DatabaseManager
from services.auth_service import AuthService
from services.stock_service import StockService
from services.alert_service import AlertService
from services.ai_summary_service import AISummaryService


class TestAuthService(unittest.TestCase):
    """Test authentication service"""
    
    def setUp(self):
        """Set up test database"""
        self.db = DatabaseManager(':memory:')  # Use in-memory database for testing
        self.auth = AuthService(self.db)
    
    def test_password_hashing(self):
        """Test password is hashed correctly"""
        password = "test123"
        hash1 = self.auth.hash_password(password)
        hash2 = self.auth.hash_password(password)
        
        self.assertEqual(hash1, hash2, "Same password should produce same hash")
        self.assertNotEqual(password, hash1, "Password should be hashed, not plaintext")
    
    def test_mobile_validation(self):
        """Test mobile number validation"""
        self.assertTrue(self.auth.validate_mobile_number("9876543210"))
        self.assertTrue(self.auth.validate_mobile_number("98765 43210"))  # With space
        self.assertFalse(self.auth.validate_mobile_number("123"))  # Too short
        self.assertFalse(self.auth.validate_mobile_number("12345678901"))  # Too long
    
    def test_password_validation(self):
        """Test password validation"""
        is_valid, msg = self.auth.validate_password("test123")
        self.assertTrue(is_valid)
        
        is_valid, msg = self.auth.validate_password("12345")  # Too short
        self.assertFalse(is_valid)
        self.assertIn("at least 6 characters", msg)
    
    def test_user_registration(self):
        """Test user registration"""
        success, msg, user_id = self.auth.register_user(
            mobile_number="9876543210",
            name="Test User",
            password="test123",
            email="test@example.com"
        )
        
        self.assertTrue(success, "Registration should succeed")
        self.assertIsNotNone(user_id, "User ID should be returned")
        
        # Test duplicate registration
        success, msg, user_id = self.auth.register_user(
            mobile_number="9876543210",
            name="Another User",
            password="test123"
        )
        self.assertFalse(success, "Duplicate registration should fail")
        self.assertIn("already exists", msg)
    
    def test_user_login(self):
        """Test user login"""
        # Register user first
        self.auth.register_user("9876543210", "Test User", "test123")
        
        # Test successful login
        success, msg, user_data = self.auth.login("9876543210", "test123")
        self.assertTrue(success, "Login should succeed")
        self.assertIsNotNone(user_data, "User data should be returned")
        self.assertEqual(user_data['mobile_number'], "9876543210")
        
        # Test wrong password
        success, msg, user_data = self.auth.login("9876543210", "wrong_password")
        self.assertFalse(success, "Login should fail with wrong password")
        
        # Test non-existent user
        success, msg, user_data = self.auth.login("0000000000", "test123")
        self.assertFalse(success, "Login should fail for non-existent user")


class TestStockService(unittest.TestCase):
    """Test stock service"""
    
    def setUp(self):
        """Set up stock service"""
        self.stock_service = StockService()
    
    def test_get_stock_info_valid(self):
        """Test fetching valid stock info"""
        # Test with a well-known stock
        info = self.stock_service.get_stock_info("AAPL")
        
        if info:  # Only test if we have internet connection
            self.assertIsNotNone(info)
            self.assertIn('symbol', info)
            self.assertIn('company_name', info)
            self.assertIn('current_price', info)
    
    def test_get_stock_info_invalid(self):
        """Test fetching invalid stock"""
        info = self.stock_service.get_stock_info("INVALID_SYMBOL_XYZ")
        self.assertIsNone(info, "Invalid stock should return None")
    
    def test_calculate_pnl(self):
        """Test P&L calculation"""
        result = self.stock_service.calculate_pnl(
            avg_price=100.0,
            current_price=120.0,
            quantity=10
        )
        
        self.assertEqual(result['total_invested'], 1000.0)
        self.assertEqual(result['current_value'], 1200.0)
        self.assertEqual(result['pnl'], 200.0)
        self.assertEqual(result['pnl_percentage'], 20.0)
    
    def test_calculate_pnl_loss(self):
        """Test P&L calculation with loss"""
        result = self.stock_service.calculate_pnl(
            avg_price=100.0,
            current_price=80.0,
            quantity=10
        )
        
        self.assertEqual(result['pnl'], -200.0)
        self.assertEqual(result['pnl_percentage'], -20.0)


class TestDatabaseManager(unittest.TestCase):
    """Test database operations"""
    
    def setUp(self):
        """Set up test database"""
        self.db = DatabaseManager(':memory:')
    
    def test_create_user(self):
        """Test creating a user"""
        user_id = self.db.create_user(
            mobile_number="9876543210",
            name="Test User",
            password_hash="hashed_password"
        )
        
        self.assertIsNotNone(user_id)
        self.assertGreater(user_id, 0)
    
    def test_get_user_by_mobile(self):
        """Test retrieving user by mobile"""
        # Create user
        self.db.create_user("9876543210", "Test User", "hash")
        
        # Retrieve user
        user = self.db.get_user_by_mobile("9876543210")
        self.assertIsNotNone(user)
        self.assertEqual(user['name'], "Test User")
        
        # Non-existent user
        user = self.db.get_user_by_mobile("0000000000")
        self.assertIsNone(user)
    
    def test_add_stock(self):
        """Test adding a stock"""
        # Create user first
        user_id = self.db.create_user("9876543210", "Test User", "hash")
        
        # Add stock
        stock_id = self.db.add_stock(
            user_id=user_id,
            symbol="AAPL",
            company_name="Apple Inc.",
            exchange="NASDAQ"
        )
        
        self.assertIsNotNone(stock_id)
        self.assertGreater(stock_id, 0)
        
        # Test duplicate stock returns same ID
        stock_id2 = self.db.add_stock(user_id, "AAPL", "Apple Inc.", "NASDAQ")
        self.assertEqual(stock_id, stock_id2)
    
    def test_add_transaction(self):
        """Test adding a transaction"""
        user_id = self.db.create_user("9876543210", "Test User", "hash")
        stock_id = self.db.add_stock(user_id, "AAPL", "Apple Inc.", "NASDAQ")
        
        transaction_id = self.db.add_transaction(
            stock_id=stock_id,
            transaction_type="BUY",
            quantity=10,
            price_per_share=150.0,
            transaction_date="2024-01-01",
            investment_horizon="LONG",
            target_price=200.0,
            thesis="Good company"
        )
        
        self.assertIsNotNone(transaction_id)
        self.assertGreater(transaction_id, 0)
    
    def test_get_portfolio_summary(self):
        """Test portfolio summary calculation"""
        user_id = self.db.create_user("9876543210", "Test User", "hash")
        stock_id = self.db.add_stock(user_id, "AAPL", "Apple Inc.", "NASDAQ")
        
        # Add buy transaction
        self.db.add_transaction(
            stock_id=stock_id,
            transaction_type="BUY",
            quantity=10,
            price_per_share=100.0,
            transaction_date="2024-01-01",
            investment_horizon="LONG"
        )
        
        portfolio = self.db.get_portfolio_summary(user_id)
        
        self.assertEqual(len(portfolio), 1)
        self.assertEqual(portfolio[0]['symbol'], "AAPL")
        self.assertEqual(portfolio[0]['quantity'], 10)
        self.assertEqual(portfolio[0]['avg_price'], 100.0)


class TestAlertService(unittest.TestCase):
    """Test alert service"""
    
    def setUp(self):
        """Set up test environment"""
        self.db = DatabaseManager(':memory:')
        self.alert_service = AlertService(self.db)
    
    def test_create_manual_alert(self):
        """Test creating manual alert"""
        user_id = self.db.create_user("9876543210", "Test User", "hash")
        stock_id = self.db.add_stock(user_id, "AAPL", "Apple Inc.", "NASDAQ")
        
        alert_id = self.alert_service.create_manual_alert(
            stock_id=stock_id,
            alert_type="ANNOUNCEMENT",
            message="Q3 Results",
            details="Revenue up 20%"
        )
        
        self.assertIsNotNone(alert_id)
        self.assertGreater(alert_id, 0)
    
    def test_get_user_alerts(self):
        """Test retrieving user alerts"""
        user_id = self.db.create_user("9876543210", "Test User", "hash")
        stock_id = self.db.add_stock(user_id, "AAPL", "Apple Inc.", "NASDAQ")
        
        # Create alert
        self.alert_service.create_manual_alert(
            stock_id=stock_id,
            alert_type="ANNOUNCEMENT",
            message="Test Alert"
        )
        
        alerts = self.alert_service.get_user_alerts(user_id)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0]['alert_message'], "Test Alert")


class TestAISummaryService(unittest.TestCase):
    """Test AI summary service"""
    
    def setUp(self):
        """Set up AI service"""
        self.ai_service = AISummaryService()
    
    def test_service_initialization(self):
        """Test AI service initializes without error"""
        self.assertIsNotNone(self.ai_service)
    
    def test_is_available(self):
        """Test checking if AI is available"""
        # This will be False unless API key is configured
        available = self.ai_service.is_available()
        self.assertIsInstance(available, bool)
    
    def test_extract_sentiment(self):
        """Test sentiment extraction"""
        positive_text = "SENTIMENT: POSITIVE - Strong growth expected"
        negative_text = "SENTIMENT: NEGATIVE - Declining revenues"
        neutral_text = "SENTIMENT: NEUTRAL - Stable performance"
        
        self.assertEqual(
            self.ai_service._extract_sentiment(positive_text),
            'POSITIVE'
        )
        self.assertEqual(
            self.ai_service._extract_sentiment(negative_text),
            'NEGATIVE'
        )
        self.assertEqual(
            self.ai_service._extract_sentiment(neutral_text),
            'NEUTRAL'
        )


def run_tests():
    """Run all unit tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestAuthService))
    suite.addTests(loader.loadTestsFromTestCase(TestStockService))
    suite.addTests(loader.loadTestsFromTestCase(TestDatabaseManager))
    suite.addTests(loader.loadTestsFromTestCase(TestAlertService))
    suite.addTests(loader.loadTestsFromTestCase(TestAISummaryService))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Return success/failure
    return result.wasSuccessful()


if __name__ == '__main__':
    success = run_tests()
    sys.exit(0 if success else 1)
